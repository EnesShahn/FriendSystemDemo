import * as admin from "firebase-admin";
import {DocumentData, DocumentReference} from "firebase-admin/firestore";

const firestore = admin.firestore();
const usersCollection = firestore.collection("Users");
const invitesCollection = firestore.collection("Invites");
const groupChatCollection = firestore.collection("GroupChat");
const privateChatCollection = firestore.collection("PrivateChat");

export const getUserDocInfo = async function (
  uid: string
): Promise<[DocumentData | undefined, DocumentReference | undefined]> {
  const querySnapshot = await usersCollection.where("uid", "==", uid).get();
  const docSnapshot = querySnapshot.docs[0];
  if (querySnapshot.empty || docSnapshot == undefined)
  {
    return [undefined, docSnapshot.ref];
  }
  return [docSnapshot.data(), docSnapshot.ref];
};

export const getGroupDocInfo = async function (
  groupId: string
): Promise<[DocumentData | undefined, DocumentReference | undefined]> {
  const docSnapshot = await groupChatCollection.doc(groupId).get();
  const docData = docSnapshot.data();
  if (!docSnapshot.exists || docData == undefined)
  {
    return [undefined, undefined];
  }
  return [docData, docSnapshot.ref];
};

export const getPrivateChat = async function (
  userId: string,
  friendId: string
): Promise<[DocumentData | undefined, DocumentReference | undefined]> {
  let docSnapshot = await privateChatCollection.doc(userId + friendId).get();
  if (!docSnapshot.exists)
  {
    docSnapshot = await privateChatCollection.doc(friendId + userId).get();
  }
  const docData = docSnapshot.data();
  if (!docSnapshot.exists || docData == undefined)
  {
    return [undefined, undefined];
  }
  return [docData, docSnapshot.ref];
};

export const getInviteDocInfoByInviteId = async function (
  inviteId: string
): Promise<[DocumentData | undefined, DocumentReference | undefined]> {
  const docSnapshot = await invitesCollection.doc(inviteId).get();
  const docData = docSnapshot.data();
  if (!docSnapshot.exists || docData == undefined)
  {
    return [undefined, undefined];
  }
  return [docData, docSnapshot.ref];
};

export const getInviteDocInfoBySenderAndReceiver = async function (
  senderId: string,
  receiverId: string
): Promise<[DocumentData | undefined, DocumentReference | undefined]> {
  const querySnapshot = await invitesCollection
    .where("senderId", "==", senderId)
    .where("receiverId", "==", receiverId)
    .get();
  const docSnapshot = querySnapshot.docs[0];
  const docData = docSnapshot.data();
  if (!docSnapshot.exists || docData == undefined)
  {
    return [undefined, undefined];
  }
  return [docData, docSnapshot.ref];
};
