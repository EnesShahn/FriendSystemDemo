import * as admin from "firebase-admin";

admin.initializeApp();

import * as inviteManagement from "./invitationManagement";
import * as userManagement from "./userManagement";
import * as friendManagement from "./friendManagement";
import * as groupManagement from "./groupManagement";

const settings = {
  timestampsInSnapshots: true,
};
admin.firestore().settings(settings);

export const getAllFriends = friendManagement.getAllFriends;
export const getPrivateChat = friendManagement.getPrivateChat;
export const removeFriend = friendManagement.removeFriend;
export const sendFriendInvitation = friendManagement.sendFriendInvitation;
export const sendFriendMessage = friendManagement.sendFriendMessage;

export const createGroup = groupManagement.createGroup;
export const getAllGroupIds = groupManagement.getAllGroups;
export const getGroup = groupManagement.getGroup;
export const leaveGroup = groupManagement.leaveGroup;
export const sendGroupInvitation = groupManagement.sendGroupInvitation;
export const sendGroupInvite = groupManagement.sendGroupInvite;
export const sendGroupMessage = groupManagement.sendGroupMessage;

export const getPendingInvitations = inviteManagement.getPendingInvitations;
export const acceptInvite = inviteManagement.acceptInvite;
export const rejectInvite = inviteManagement.rejectInvite;

export const onUserRegistered = userManagement.onUserRegistered;
