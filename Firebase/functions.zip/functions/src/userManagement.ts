import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as logger from "firebase-functions/logger";

const firestore = admin.firestore();

// export const signup = functions.https.onRequest((request, response) => {
//   const email = request.body.data.email;
//   const password = request.body.data.password;

//   admin.auth().createUser({
//     email: email,
//     password: password,
//     emailVerified: false,
//   }).then((userRecord) => {
//     logger.log("Successfully created new user: " + userRecord.uid);
//     response
//       .status(200)
//       .send("Successfully created new user: " + userRecord.uid);
//   }).catch((error) => {
//     logger.log("Error creating new user: " + error);
//     response.status(404).send("Error creating new user: " + error);
//   });
// });

//  ************  Triggers  ************

export const onUserRegistered = functions.auth.user().onCreate((user) => {
  logger.log("New User registered");

  firestore.collection("Users").add({
    uid: user.uid,
    email: user.email,
  });
});
