import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as helper from "./helper";
import {FieldValue} from "firebase-admin/firestore";

const firestore = admin.firestore();
const invitesCollection = firestore.collection("Invites");
const groupsCollection = firestore.collection("Groups");

export const createGroup = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupName} = req.body;
    if (!groupName)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    firestore.runTransaction(async (t) => {
      const groupDocRef = groupsCollection.doc();
      t.create(groupDocRef, {
        name: groupName,
        creator: userId,
        members: FieldValue.arrayUnion(userId),
      });

      t.update(userDocRef, {
        groups: FieldValue.arrayUnion(groupDocRef.id),
      });
    });
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const sendGroupInvite = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupId, receiverId} = req.body;
    if (!groupId || !receiverId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const [groupDocData, groupDocRef] = await helper.getGroupDocInfo(groupId);
    if (!groupDocData || !groupDocRef)
    {
      res.status(404).send("Group doesn't exist");
      return;
    }

    if (groupDocData.creator != userId)
    {
      res.status(400).send("You are not the creator");
      return;
    }

    const [invitationDocData, invitationDocRef] = await helper.getInviteDocInfoBySenderAndReceiver(groupId, receiverId);
    if (invitationDocData && invitationDocRef)
    {
      res.status(400).send("Invite already sent");
      return;
    }

    invitesCollection.add({
      inviteType: "Group",
      senderId: groupId,
      receiverId: receiverId,
      status: "Pending",
    });
    res.status(200);

  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const getAllGroups = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const groups = userDocData.groups as Array<string>;
    res.status(200).send({data: groups});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const getGroup = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupId} = req.body;
    if (!groupId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    if (!userDocData.groups.includes(groupId))
    {
      res.status(400).send("You are not member of the group");
      return;
    }

    const [groupDocData, groupDocRef] = await helper.getGroupDocInfo(groupId);
    if (!groupDocData || !groupDocRef)
    {
      res.status(404).send("Group doesn't exist");
      return;
    }

    res.status(200).send({data: groupDocData});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
});

export const sendGroupInvitation = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupId, receiverId} = req.body;
    if (!groupId || !receiverId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const [groupDocData, groupDocRef] = await helper.getGroupDocInfo(groupId);
    if (!groupDocData || !groupDocRef)
    {
      res.status(404).send("Group doesn't exist");
      return;
    }

    const groupMemebers = userDocData.members as Array<string>;
    if (groupMemebers.includes(receiverId))
    {
      res.status(400).send("Receiver is already part of the group");
      return;
    }

    const [receiverDocData, receiverDocRef] = await helper.getUserDocInfo(receiverId);
    if (!receiverDocData || !receiverDocRef)
    {
      res.status(400).send("Receiver doesn't exist.");
      return;
    }

    const inviteExistsQuerySnapshot = await invitesCollection
      .where("senderd", "==", groupId)
      .where("receiverId", "==", receiverId)
      .get();

    if (inviteExistsQuerySnapshot.empty)
    {
      res.status(400).send("Invite already sent");
      return;
    }

    const invitationData = {
      invitationType: "Group",
      senderId: groupId,
      receiverId: receiverId,
      status: "Pending",
    }

    invitesCollection.add(invitationData);
    res.status(200).send({data: invitationData});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const sendGroupMessage = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupId, message} = req.body;
    if (!groupId || !message)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    if (!userDocData.groups.includes(groupId))
    {
      res.status(400).send("You are not part of the group");
      return;
    }

    const [groupDocData, groupDocRef] = await helper.getGroupDocInfo(groupId);
    if (!groupDocData || !groupDocRef)
    {
      res.status(404).send("Group doesn't exist");
      return;
    }

    const messageData = {
      senderId: userId,
      timestamp: admin.database.ServerValue.TIMESTAMP,
      content: message,
    };

    const groupDocMessageRef = groupDocRef?.collection("messages").doc();
    if (!groupDocMessageRef) return;
    groupDocMessageRef.create(messageData);

    res.status(200).send({data: messageData});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const leaveGroup = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {groupId} = req.body;
    if (!groupId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    if (!userDocData.groups.includes(groupId))
    {
      res.status(400).send("You are not part of the group");
      return;
    }

    const [groupDocData, groupDocRef] = await helper.getGroupDocInfo(groupId);
    if (!groupDocData || !groupDocRef)
    {
      res.status(404).send("Group doesn't exist");
      return;
    }

    firestore.runTransaction(async (t) => {
      t.update(groupDocRef, {
        members: admin.firestore.FieldValue.arrayRemove(userId),
      });

      if (groupDocData?.creator == userId)
      {
        //  get all the other members
        //  choose one randomly?? and then make the user the creator
        const groupDocSnapshot = await t.get(groupDocRef);
        const groupDocData = await groupDocSnapshot.data();
        const groupMembers = groupDocData?.members as Array<string>;

        if (groupMembers.length == 0)
        {
          //  Remove the whole group
          t.delete(groupDocRef);
        } else
        {
          t.update(groupDocRef, {
            creator: groupMembers[0],
          });
        }
      }
    });
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);
