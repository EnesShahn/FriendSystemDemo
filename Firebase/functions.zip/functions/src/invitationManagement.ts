import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as helper from "./helper";

const firestore = admin.firestore();
const invitesCollection = firestore.collection("Invites");
const groupsCollection = firestore.collection("Groups");

export const getPendingInvitations = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const invitesQuerySnapshot = await invitesCollection
      .where("status", "==", "Pending")
      .where("receiverId", "==", userId)
      .get();

    const pendingInvitations = invitesQuerySnapshot.docs
      .filter(docSnapshot => docSnapshot.exists)
      .map(docSnapshot => docSnapshot.data());

    res.status(200).send({data: pendingInvitations});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const acceptInvite = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {inviteId} = req.body;

    if (!inviteId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const [inviteDocData, inviteDocRef] = await helper.getInviteDocInfoByInviteId(inviteId);
    if (!inviteDocData || !inviteDocRef)
    {
      res.status(404).send("Invite doesn't exist");
      return;
    }

    const {invitationType, senderId} = inviteDocData;
    if (!invitationType || !senderId) return;
    if (!senderId) return;

    const [senderDocData, senderDocRef] = await helper.getUserDocInfo(senderId);
    if (!senderDocData || !senderDocRef)
    {
      res.status(404).send("Sender doesn't exist");
      return;
    }
    functions.logger.log(invitationType);
    if (!userDocRef || !senderDocRef) return;

    await firestore.runTransaction(async (t) => {
      if (invitationType == "Friend")
      {
        t.update(userDocRef, {
          friends: admin.firestore.FieldValue.arrayUnion(senderId),
        });
        t.update(senderDocRef, {
          friends: admin.firestore.FieldValue.arrayUnion(userId),
        });
        t.update(inviteDocRef, {
          status: "Accepted",
        });
      }
      else if (invitationType == "Group")
      {
        const groupDocRef = groupsCollection.doc(senderId);

        t.update(userDocRef, {
          groups: admin.firestore.FieldValue.arrayUnion(senderId),
        });
        t.update(groupDocRef, {
          members: admin.firestore.FieldValue.arrayUnion(userId),
        });
        t.update(inviteDocRef, {
          status: "Accepted",
        });
      }
    });

    res.status(200).send(null);
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const rejectInvite = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion


    const {inviteId} = req.body;

    if (!inviteId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const [inviteDocData, inviteDocRef] = await helper.getInviteDocInfoByInviteId(inviteId);
    if (!inviteDocData || !inviteDocRef)
    {
      res.status(404).send("Invite doesn't exist");
      return;
    }

    if (inviteDocData.receiverId != userId)
    {
      res.status(404).send("Invitation receiver doesn't match user id.");
      return;
    }

    inviteDocRef.update({status: "Rejected", });
    res.status(200);
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);
