import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as helper from "./helper";
import {FieldValue} from "firebase-admin/firestore";

const firestore = admin.firestore();
const invitesCollection = firestore.collection("Invites");
const privateChatCollection = firestore.collection("PrivateChat");

export const getAllFriends = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const myFriends = userDocData?.friends as Array<string>;
    res.status(200).send({data: myFriends});
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const getPrivateChat = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {friendId} = req.body;
    if (!friendId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const myFriends = userDocData?.friends as Array<string>;
    if (!myFriends.includes(friendId))
    {
      res.status(400).send("Already friends");
      return;
    }

    let [privateChatDocData, privateChatDocRef] = await helper.getPrivateChat(userId, friendId);
    if (!privateChatDocData || !privateChatDocRef)
    {
      //  Private chat doesn't exist.. create one here
      privateChatDocRef = privateChatCollection.doc(userId + friendId);
      privateChatDocRef.create({members: [userId, friendId]});
    }

    res.status(200).send({data: privateChatDocData, });
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const sendFriendInvitation = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {friendId} = req.body;
    if (!friendId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const myFriends = userDocData?.friends as Array<string>;
    if (!myFriends.includes(friendId))
    {
      res.status(400).send("Already friends");
      return;
    }

    const [friendDocData, friendDocRef] = await helper.getUserDocInfo(friendId);
    if (!friendDocData || !friendDocRef)
    {
      res.status(400).send("Friend doesn't exist.");
      return;
    }

    const invitesQuerySnapshot = await invitesCollection
      .where("senderId", "==", userId)
      .where("receiverId", "==", friendId)
      .get();

    if (!invitesQuerySnapshot.empty)
    {
      res.status(400).send("Invite already exists");
      return;
    }

    const data = {
      invitationType: "Friend",
      senderId: userId,
      receiverId: friendId,
      status: "Pending",
    };

    invitesCollection.add(data);

    res.status(200).send({data: data, });
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const removeFriend = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {friendId} = req.body;
    if (!friendId)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const myFriends = userDocData?.friends as Array<string>;
    if (!myFriends.includes(friendId))
    {
      res.status(400).send("Already friends");
      return;
    }

    const [friendDocData, friendDocRef] = await helper.getUserDocInfo(friendId);
    if (!friendDocData || !friendDocRef)
    {
      res.status(400).send("Friend doesn't exist.");
      return;
    }

    await firestore.runTransaction(async (t) => {
      t.update(userDocRef, {
        friends: FieldValue.arrayRemove(friendId),
      });

      t.update(friendDocRef, {
        friends: FieldValue.arrayRemove(userId),
      });
    });

    res.status(200);
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);

export const sendFriendMessage = functions.https.onRequest(async (req, res) => {
  try
  {
    //#region Validation 
    if (req.method !== 'POST')
    {
      res.status(400).send('Bad request, this endpoint only accepts POST requests');
      return;
    }

    const idToken = req.headers.authorization?.split('Bearer ')[1];
    if (!idToken)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    const userId = decodedToken.uid;

    if (!userId)
    {
      res.status(401).send('You are not authorized to perform this action');
      return;
    }
    //#endregion

    const {friendId, message} = req.body;

    if (!friendId || !message)
    {
      res.status(400).send("Invalid arguments");
      return;
    }

    const [userDocData, userDocRef] = await helper.getUserDocInfo(userId);
    if (!userDocData || !userDocRef)
    {
      res.status(400).send("User doesn't exist");
      return;
    }

    const myFriends = userDocData?.friends as Array<string>;
    if (!myFriends.includes(friendId))
    {
      res.status(400).send("Already friends");
      return;
    }

    let [privateChatDocData, privateChatDocRef] = await helper.getPrivateChat(userId, friendId);
    if (!privateChatDocData || !privateChatDocRef)
    {
      //  Private chat doesn't exist.. create one here
      privateChatDocRef = privateChatCollection.doc(userId + friendId);
      privateChatDocRef.create({members: [userId, friendId]});
    }

    await firestore.runTransaction(async (t) => {
      const privateChatDocMessagesRef = privateChatDocRef?.collection("messages").doc();
      if (!privateChatDocMessagesRef)
        return;

      const newMessage = {
        senderId: userId,
        timestamp: admin.database.ServerValue.TIMESTAMP,
        content: message,
      };

      t.create(privateChatDocMessagesRef, newMessage);

      res.status(200).send({data: newMessage});
    });
  } catch (error)
  {
    res.status(400).send("Error: " + error);
  }
}
);
